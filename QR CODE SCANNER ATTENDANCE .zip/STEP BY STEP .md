 - - - - - - 
 - - - - -
 
[![DEVOPCODER](https://img.shields.io/badge/STEP_BY_STEP-CYBERPUNK-F72585?style=for-the-badge&logo=github)](https://shields.io)

[![BY MARCELO](https://img.shields.io/badge/BY-MARCELO-4895EF?style=for-the-badge)](https://github.com)

[![GOOD LUCK](https://img.shields.io/badge/GOOD_LUCK-GREEN-06D6A0?style=for-the-badge)](https://shields.io)

- - - - - - 
- - - - -

STEP 1 = MAKE A GOOGLE SHEET AT 

➡️ [CLICK ME TO OPEN THE LINK](https://docs.google.com/spreadsheets/u/0/)⬅️
 
 - - - - - - 
 - - - - -
 
 STEP 2 = MAKE A HEADERS IN ROW 1 📌 optional (column c section)
 
 SHEET ONE
![BANNER](https://imgur.com/U6JL4VZ.jpg)
 
 SHEET TWO 
 
 📌THE LIST OF MASTER LIST FOR ➡️ ABSENT AND PRESENT DETECTION⬅️ 
![BANNER](https://imgur.com/jqJaCYX.jpg)
 
 - - - - - - 
 - - - - -
 
STEP 3 =  EDIT THE EMAIL OF ADDMIN , ADVISER AND TIME LATE EDIT



.➡️FILE NAME
![BANNER](https://imgur.com/gV7fNk1.jpg)
.
➡️LINE OF EDIT EMAIL
![BANNER](https://imgur.com/CYnqVzW.jpg)
 
 .➡️LINE OF TIME EDIT
![BANNER](https://imgur.com/fVPLhtq.jpg)

 ➡️[THE APP I USE CLICK ME TO DOWNLOAD](https://play.google.com/store/apps/details?id=io.spck)⬅️
 
 - - - - - - 
 - - - - -
 
 STEP 4 = IN GOOGLE SHEET
 
 📌NOTES: ⚠️ IF YOUR CODING IN THE CELLPHONE 📱 ⚠️IN CHROME CLICK THE THREE DOTS AND DESKTOP SITE TO SEE THE EXTENSION IN GOOGLE SHEET.

➡️ EXTENSION 

➡️ APPS SCRIPT 

➡️ YOU SEE THIS CODE ![BANNER](https://imgur.com/fSNrzYq.jpg) 

➡️ DELETE IT 

➡️ COME BACK TO THE TEMPLATE COPY THE CODE AND PASTE IT AT APPS SCRIPT ⬇️ ⬇️ 

![BANNER](https://imgur.com/gV7fNk1.jpg)

➡️ CLICK THE RUN BUTTON THE PLAY BUTTON ON TOP ▶️

 - - - - - -
 - - - - -

STEP 5 = IN GOOGLE SHEET CLICK 

![BANNER](https://imgur.com/wcjbyEU.jpg)
➡️ CLICK DEPLOY 


 📌Authorize Permissions📱
 
Kapag unang beses mong dini-deploy:

1 Lalabas ang Google authorization dialog.

2 Piliin ang Google account mo.

3 Advance

![BANNER](https://imgur.com/XhgEWwR.jpg)

4 Click Allow.

5 COPY THE URL WEB APP
![BANNER](https://imgur.com/rUktyF1.jpg)

 - - - - - -
 - - - - -

STEP 6 = HTML EDIT THE LINK PLACE YOUR WEB APP LINK 
![BANNER](https://imgur.com/pdZs9g5.jpg)

![BANNER](https://imgur.com/3mSRCYO.jpg)

 - - - - - - 
 - - - - -

STEP 7 = MAKE A GIT HUB ACCOUNT ⬇️⬇️⬇️

➡️[CLICK ME TO MAKE AN ACCOUNT](https://github.com)⬅️

➡️LOGIN IN THE ACCOUNT YOU MAKE AND MAKE A REPO FOR SERVER WEBSITE 
➡️[CLICK ME TO MAKE REPO](https://github.new)⬅️

![BANNER](https://imgur.com/kYqn4je.jpg) 
➡️ CLICK CREATE Repository

![BANNER](https://imgur.com/PDjxj6u.jpg)

![BANNER](https://imgur.com/AfO5xdJ.jpg)

![BANNER](https://imgur.com/dj4iAsP.jpg)

📌STEP 5 CLICK PAGES 

📌IN STEP 7 THE SHOULD THE POP UP MESSAGE GitHub Pages source saved.

📌IN STEP 8 WAIT 1 TO 2 MINUTES 
AND CLICK VISIT THE SITE 

📌STEP 9 IF THE WEBSITE ASK PERMISSION TO USE CAMERA JUST ALLOW IT

- - - - - -
- - - - -

STEP 8 = BACK TO THE GOOGLE SHEET 

➡️ EXTENSION 

➡️ APPS SCRIPT 

➡️ IN LEFT SIDE FING THE CLOCK ⏰ ICON AND JUST CLICK IT 

➡️ ADD TRIGGER 

![BANNER](https://imgur.com/LrZmj69.jpg)
CLICK SAVE
![BANNER](https://imgur.com/KlwmcIU.jpg)
CLICK SAVE
![BANNER](https://imgur.com/SCWbEfw.jpg)
CLICK SAVE
![BANNER](https://imgur.com/43fWGeC.jpg)
CLICK SAVE
![BANNER](https://imgur.com/NBuyvA7.jpg)
CLICK SAVE
![BANNER](https://imgur.com/Hh6qSUE.jpeg)
CLICK SAVE

📌IF AUTHORIZATION APPEAR 

 📌Authorize Permissions📱
 
Kapag unang beses mong dini-deploy:

1 Lalabas ang Google authorization dialog.

2 Piliin ang Google account mo.

3 Advance

![BANNER](https://imgur.com/XhgEWwR.jpg)

4 Click Allow.

 - - - - - 
 - - - - - -

STEP 9 = MAKE QR CODE EVERY STUDENT 

➡️[CLICK ME TO CREATE](https://devopcoder.github.io/QR-GENERATOR-PBHNS/)⬅️

📌NOTE:whatever their name is on the master list, their name should be the same on the qr code if it's long example maria princess, santos that should be what's on the qr code and master list or ask your advisor for the master list then just copy and paste it

 - - - - - -
 - - - - - -
 
 STEP 10 = MAKE BOT BACK TO THE GITHUB ACCOUNT YOU CREATED 
 
SELECT YOUR REPO YOU CREATED 

➡️Tap Add file → Create new file

➡️File name:.github/workflows/attendance-bot.yml


COPY THAT ⬆️⬆️⬆️⬆️⬆️⬆️⬆️

➡️COME BACK TO THE TEMPLE FIND THE BOT CODE.text AND EDIT THE URL AND IF DONE EDIT THE URL COPY THE CODE AND PASTE IT ON GITHUB 

![BANNER](https://imgur.com/hZe49zb.jpg)

 - - - - - -
 - - - - - -